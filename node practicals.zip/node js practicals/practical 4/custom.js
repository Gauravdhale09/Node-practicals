var calculator = require('./calc');

var x=50,y=20;

console.log(calculator.add(x,y));


console.log(calculator.sub(x,y));


console.log(calculator.mult(x,y));


console.log(calculator.div(x,y));