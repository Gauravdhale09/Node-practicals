let sum = require('./mymodule')

console.log(sum.add(10,20));