exports.add = function(n,m)
{
	return n+m;

}